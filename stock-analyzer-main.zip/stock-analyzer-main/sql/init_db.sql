-- initialization script for Postgres container
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- (additional init steps can be added here)
